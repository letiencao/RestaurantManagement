package com.letiencao.dto.response.tableseating;

import com.letiencao.dto.BaseDTO;

import lombok.Getter;
import lombok.Setter;
@Getter
@Setter
public class TableSeatingDTO extends BaseDTO{
	private int id;
	private String name;

//	private List<ReservationEntity> reservationEntities;
}
