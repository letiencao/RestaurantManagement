package com.letiencao.service.impl;

import org.springframework.stereotype.Service;

import com.letiencao.service.IReservationDetailsService;

@Service
public class ReservationDetailsService implements IReservationDetailsService{

}
