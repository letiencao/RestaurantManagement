//package com.letiencao.exception;
//
//public class UserNotFoundException extends RuntimeException {
//
//}
