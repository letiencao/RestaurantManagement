package com.letiencao.dto;

import com.letiencao.entity.UserEntity;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RefreshTokenDTO {
	
	private int id;
	
	private String token;
	
	private UserEntity userEntity;

	private long expiryDate;
}
