package com.letiencao.dto.request;

import lombok.Getter;

import lombok.Setter;

@Getter
@Setter
public class SearchByNameRequest {
	private String name;

}
